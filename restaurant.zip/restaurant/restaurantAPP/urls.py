from django.urls import path

from . import views

app_name = "restaurantAPP"

urlpatterns = [
    path("", views.home, name = "home"),
    path("ingredients", views.displayIngredients, name ="displayIngredients"),
    path("dishes", views.dishes, name = "dishes"),
    path("updateIngredient", views.updateIngredients, name = "updateIngredient"),
    path("menus", views.displayMenus, name ="displayMenus"),
    path("addNewMenu", views.addNewMenu, name="addNewMenu"),
]
