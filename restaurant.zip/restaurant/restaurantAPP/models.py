from django.db import models

# Create your models here.
class Allergen(models.Model):
    name = models.CharField(max_length=30)
    def __str__(self):
        return self.name

class Ingredient(models.Model):
    name = models.CharField(max_length=50)
    unit = models.CharField(max_length=20)
    stock = models.DecimalField(max_digits=6, decimal_places=2)
    category = models.CharField(max_length=20)
    allergens = models.ManyToManyField(Allergen)
    def __str__(self):
        return self.name

class DishCategory(models.Model):
    name = models.CharField(max_length=30)
    def __str__(self):
        return self.name

class Dish(models.Model):
    name = models.CharField(max_length=50)
    category = models.ForeignKey(DishCategory, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    is_vegetarian = models.IntegerField(default = 0)
    is_vegan = models.IntegerField(default = 0)
    def __str__(self):
        return self.name
    
class Menu(models.Model):
    name = models.CharField(max_length=50)
    author = models.CharField(max_length=50)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    dishes = models.ManyToManyField(Dish)
    def __str__(self):
        return self.name + " " + str(self.price)
    
class Ingredient_Dish(models.Model):
    quantity = models.DecimalField(max_digits=6, decimal_places=2)
    ingredient = models.ForeignKey(Ingredient, on_delete=models.CASCADE)
    dish = models.ForeignKey(Dish, on_delete=models.CASCADE)
    def __str__(self):
        return str(self.quantity) + " " + self.ingredient.unit + " of " + str(self.ingredient) + " in " + str(self.dish)
    
class Item(models.Model):
    price = models.DecimalField(max_digits=6, decimal_places=2)
    date = models.DateField()
    expDate = models.DateField()
    supplier = models.CharField(max_length=50)
    ingredient = models.ForeignKey(Ingredient, on_delete=models.CASCADE)
    def __str__(self):
        return str(self.ingredient) + " " + str(self.expDate)
