from django import forms
from.models import Menu

class addMenuform(forms.ModelForm):
    class Meta:
        model = Menu
        fields = ["name", "author", "price", "dishes"]
        labels = {"name" : "Menu Name", "author" : "Author", "price" : "Price", "dishes" : "Dishes"}