from django.contrib import admin
from .models import Allergen, Ingredient, Dish, Menu, Ingredient_Dish, Item

admin.site.register(Allergen)
admin.site.register(Ingredient)
admin.site.register(Dish)
admin.site.register(Menu)
admin.site.register(Ingredient_Dish)
admin.site.register(Item)