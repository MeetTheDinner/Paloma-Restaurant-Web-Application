from django.shortcuts import render, redirect, get_object_or_404
from .models import Dish, Ingredient_Dish, Ingredient, Menu, DishCategory
from decimal import Decimal
#from .forms import addMenuform

def home(request):
    return render(request, "restaurantAPP/home.html")

def ingredient(request):
    return render(request, "restaurantAPP/ingredient.html")

def dishes(request):
    #dishes=Dish.objects.all()
    categories=DishCategory.objects.all()
    globalList = []
    for c in categories:
        dishesList=c.dish_set.order_by("name")
        localList=[c, dishesList]
        globalList.append(localList)
    context={"globalList":globalList} 
    return render(request, "restaurantAPP/dishes.html", context)

"""
def dishes(request):
    dishes=Dish.objects.all()
    context={"dishes":dishes}
    return render(request, "restaurantAPP/dishes.html", context)
"""

def updateIngredients(request):
    dishes=Dish.objects.all()
    for dish in dishes:
        amount=request.POST.get(str(dish.id))
        print(amount)
        ingredientList=dish.ingredient_dish_set.all()
        for i in ingredientList:
            i.ingredient.stock-=i.quantity*int(amount)
            i.ingredient.save()
            print(i.ingredient)
            print(i.ingredient.stock)
    return render(request, "restaurantAPP/updateIngredient.html")

def displayIngredients(request):
    #ingredientsList = Ingredient.objects.all()
    ingredientsList = Ingredient.objects.order_by("name")
    if request.method == "POST":
        chosen_id = request.POST.get("chosen_id")
        quantity = request.POST.get("quantity")
        
        if chosen_id and quantity:
            quantity = Decimal(quantity)
            ingredient = Ingredient.objects.get(id=chosen_id)
            ingredient.stock  +=  quantity #Updates the inventory
            ingredient.save()
        
    context = {"ingredientsList" : ingredientsList}    
    return render(request, "restaurantAPP/ingredients.html", context)
    
def displayMenus(request):
    menus = Menu.objects.all()
    context = {"menus" : menus}
    return render(request, "restaurantAPP/menu.html" , context)
    
def addNewMenu(request):
    antipastiObject = DishCategory.objects.get(name="antipasti")
    antipasti = antipastiObject.dish_set.all()
    primiObject = DishCategory.objects.get(name="primi")
    primi = primiObject.dish_set.all()
    secondiObject = DishCategory.objects.get(name="secondi")
    secondi = secondiObject.dish_set.all()

    if request.method == "POST":
        name = request.POST.get("name")
        price = request.POST.get("price")
        author = request.POST.get("author")

        # Get selected dish objects
        antipasto_id = request.POST.get("antipasti")
        primo_id = request.POST.get("primi")
        secondo_id = request.POST.get("secondi")

        new_menu = Menu(name=name, price=Decimal(price), author=author)
        new_menu.save() #Creates a menu variable to be saved for the db

        if antipasto_id:
            new_menu.dishes.add(get_object_or_404(Dish, id=antipasto_id))
        if primo_id:
            new_menu.dishes.add(get_object_or_404(Dish, id=primo_id))
        if secondo_id:
            new_menu.dishes.add(get_object_or_404(Dish, id=secondo_id))

        return redirect('restaurantAPP:displayMenus')

    context = {"antipasti": antipasti, "primi": primi, "secondi": secondi}
    return render(request, "restaurantAPP/addNewMenu.html", context)



#when its a foreign key reverse direction, use _set.all()